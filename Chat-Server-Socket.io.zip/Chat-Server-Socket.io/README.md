# Using tips:
1. You have to login to use this chat room.
2. By default, everyone is in a public Main Room after logging in.
2. Click on the user name on the left bar to send private message to a certain user in same room.
3. Only admins can see the privileges buttons.
4. The creater/administrator can add other user as admins, which will give them the same privileges to kick/ban/delete room etc.
5. The creater/administrator is able to delete a certain chat room. All users in this chatroom will be moved back to the Main Room.
6. Be able to check if a user is off-line. If a user is off line, the user's data will be cleaned. If the user is the only admin in the current room. The chatroom will pass the admin privileges to another user in the same room.
7. Leave room function is created for better navigation!
